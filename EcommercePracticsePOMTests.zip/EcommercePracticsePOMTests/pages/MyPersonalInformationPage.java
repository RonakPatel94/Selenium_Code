package EcommercePracticsePOMTests.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.*;
import java.util.Properties;
import java.util.logging.LogManager;

public class MyPersonalInformationPage {

    WebDriver driver;
    LogManager properties;
    // Locate all elements
    By btnMyPersonalInformation = By.xpath("//span[contains(text(),'My personal information')]");
    By radioGender = By.xpath("//input[@id='id_gender1']");
    By txtFirstname = By.id("firstname");
    By txtLastname = By.id("lastname");
    By listDays = By.id("days");
    By listMonths = By.id("months");
    By listYears = By.id("years");
    By txtOldPassword = By.id("old_passwd");
    By txtPassword = By.id("passwd");
    By txtConfirmPassword = By.id("confirmation");
    By btnSave = By.xpath("//span[contains(text(),'Save')]");
    //By alertSuccessMessage = By.xpath("//p[@class='alert alert-success']");


    public MyPersonalInformationPage(WebDriver driver) {
        this.driver = driver;
    }

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader("D:\\Automation\\Automation_Practice\\Basic_Automation\\src\\EcommercePracticsePOMTests\\Data\\DataFile.properties"));

        Properties prop = new Properties();
        prop.load(reader);

        try {
            prop.load(reader);
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }

    public void navigateToPersonalInformationPage() {
        driver.findElement(btnMyPersonalInformation).click();
    }

    public void setGender() {
        driver.findElement(radioGender).click();
        String Gendername = driver.findElement(radioGender).getText();
        System.out.println("The gender value is :-" + Gendername);
        
    }

    public void setFirstName() {
        driver.findElement(By.id(properties.getProperty("txtFirstname"))).clear();
        driver.findElement(By.id(properties.getProperty("txtFirstname"))).sendKeys(properties.getProperty("Firstname"));
        driver.findElement(By.id(properties.getProperty("txtFirstname"))).sendKeys();
        //driver.findElement(txtFirstname).sendKeys("Priyank-Updated");

    }

    public void setLastName() {

        driver.findElement(By.id(properties.getProperty("txtLastname"))).clear();
        driver.findElement(By.id(properties.getProperty("txtLastname"))).sendKeys(properties.getProperty("Lastname"));
        //driver.findElement(txtLastname).clear();
        //driver.findElement(txtLastname).sendKeys("Shah");
    }

    public void setDOB() {
        Select days = new Select(driver.findElement(listDays));
        days.selectByValue("23");
        Select months = new Select(driver.findElement(listMonths));
        months.selectByIndex(11);
        Select years = new Select(driver.findElement(listYears));
        years.selectByVisibleText("1983  ");
    }

    public void setPassword() {
        driver.findElement(By.id(properties.getProperty("txtOldPassword"))).sendKeys(properties.getProperty("OldPassword"));
        driver.findElement(By.id(properties.getProperty("txtPassword"))).sendKeys(properties.getProperty("Password"));
        driver.findElement(By.id(properties.getProperty("txtConfirmPassword"))).sendKeys(properties.getProperty("ConfirmPassword"));
        //driver.findElement(txtOldPassword).sendKeys("priyank17");
        //driver.findElement(txtPassword).sendKeys("priyank17");
        //driver.findElement(txtConfirmPassword).sendKeys("priyank17");
    }

    public void savePersonalInformation() {
        driver.findElement(btnSave).click();
    }

        /*public String getAlertSuccessMessage () {
            return driver.findElement(alertSuccessMessage).getText();
        }*/
}



