package EcommercePracticsePOMTests.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.internal.Utils;

public class LoginPage {

    WebDriver driver;

    // Locate all elements of Login page
    By linkSignIn = By.xpath("//a[@class='login']");
    By txtEmail = By.id("email");
    By txtPassword = By.id("passwd");
    By btnSignIn = By.xpath("//p[@class='submit']//span[1]");
    By linkLogout = By.xpath("//a[@class='logout']");
    private Utils FileUtils;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void SigninBtn() {
        driver.findElement(linkSignIn).click();
    }

    // Set Username
    public void setUserName(String email) {
        driver.findElement(txtEmail).sendKeys(email);
    }

    // Set Password
    public void setPassword(String password) {
        driver.findElement(txtPassword).sendKeys(password);
    }

    //Click on Sign-in button
    public void clickLoginBtn() {
        driver.findElement(btnSignIn).click();
    }

    //Click on Sign-out button
    public void clickSignoutBtn() {
        driver.findElement(linkLogout).click();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public void loginToSite(String email, String password) {
        // fill email
        setUserName(email);

        // fill password
        setPassword(password);

        // click on sign-in button
        clickLoginBtn();

    }

    public void logoutFromSite() {

        // click on sign-out button
        clickSignoutBtn();
    }

}
