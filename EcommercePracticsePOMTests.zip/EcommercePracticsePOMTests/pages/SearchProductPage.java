package EcommercePracticsePOMTests.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class SearchProductPage {
    WebDriver driver;

    // Locate all elements
    By txtSearchBox = By.xpath("//input[@id='search_query_top']");
    By spanMessage = By.xpath("//span[@class='heading-counter']");


    public SearchProductPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterSearchText(String searchText) {

        //enter text in search text
        driver.findElement(txtSearchBox).sendKeys(searchText);

        //enter Enter using keyboard
        driver.findElement(txtSearchBox).sendKeys(Keys.ENTER);
    }

    public String getSearchMessage()
    {
        return driver.findElement(spanMessage).getText();
    }

}
