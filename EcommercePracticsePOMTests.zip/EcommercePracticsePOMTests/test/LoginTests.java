package EcommercePracticsePOMTests.test;

import EcommercePracticsePOMTests.pages.LoginPage;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.internal.Utils;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class LoginTests {

    public WebDriver driver;
    LoginPage loginObj;
    private Utils FileUtils;


    @BeforeClass
    public void setup() {

        // Define Chrome Driver
        System.setProperty("webdriver.chrome.driver", "resources\\chromedriver.exe");
        driver = new ChromeDriver();

        // maximize the browser
        driver.manage().window().maximize();

        // set Implicit wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

    }

    @BeforeMethod
    @Parameters({"appURL", "username", "password"})
    public void checkLogin(String AppURL, String username, String password) throws Exception {

        // Open Application URL
        driver.get(AppURL);

        //Create Login Page object
        loginObj = new LoginPage(driver);

        //Verify login page title
        String actualLoginPageTitle = loginObj.getPageTitle();
        Assert.assertEquals(actualLoginPageTitle, "My Store");

        //login to application
        loginObj.SigninBtn();
        loginObj.loginToSite(username, password);

        // Assertion for Login

        Assert.assertFalse(actualLoginPageTitle.toLowerCase().contains("Login - My Store"));

    }

    @AfterMethod
    public void checkLogOut() {
        //logout from application

        loginObj.logoutFromSite();
    }

    public void Screenshot(ITestResult testResult) throws IOException {
        if (testResult.getStatus() == ITestResult.FAILURE) {
            System.out.println(testResult.getStatus());
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("errorScreenshots\\" + testResult.getName() + "-"
                    + Arrays.toString(testResult.getParameters()) + ".jpg"));

        }
    }


   /* @AfterClass
    public void teardown() {
        // Close browser
        driver.quit();
    }*/

}
