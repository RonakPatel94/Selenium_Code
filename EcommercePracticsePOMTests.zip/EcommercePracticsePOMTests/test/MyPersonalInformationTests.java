package EcommercePracticsePOMTests.test;

import EcommercePracticsePOMTests.pages.MyPersonalInformationPage;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class MyPersonalInformationTests extends LoginTests {
    MyPersonalInformationPage objMPI;

    @Test(description = "Update personal Information")
    public void updatePersonalInformation() throws IOException {

        objMPI = new MyPersonalInformationPage(driver);
        //objMPI.Datafile();
        objMPI.navigateToPersonalInformationPage();
        objMPI.setGender();
        objMPI.setFirstName();
        objMPI.setLastName();
        objMPI.setDOB();
        objMPI.setPassword();
        objMPI.savePersonalInformation();

        //verify my personal information saved successfully
       /* String expectedSaveMsg = "Your personal information has been successfully updated.";
        String actualSaveMsg = objMPI.getAlertSuccessMessage();
        Assert.assertEquals(actualSaveMsg, expectedSaveMsg);*/

    }
}
