package EcommercePracticsePOMTests.test;

import EcommercePracticsePOMTests.pages.SearchProductPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SearchProductTests extends LoginTests {

    SearchProductPage objSP;

    @BeforeMethod
    public void setupSearchProductTests() {
        objSP = new SearchProductPage(driver);
    }

    @Test(description = "Search Invalid product")
    public void searchInvalidProductTest() {
        objSP.enterSearchText("tshirt");
        //verify search result count
        String expectedMessage = "0 results have been found.";
        String actualMsg = objSP.getSearchMessage();
        Assert.assertEquals(actualMsg, expectedMessage);
    }

    @Test(description = "Search Valid Product")
    public void searchValidProductTest() {

        objSP.enterSearchText("t-shirt");
        //verify search result count
        String expectedMessage = "1 result has been found.";
        String actualMsg = objSP.getSearchMessage();
        Assert.assertEquals(actualMsg, expectedMessage);
    }
}
